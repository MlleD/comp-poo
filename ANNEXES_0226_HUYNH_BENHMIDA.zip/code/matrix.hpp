#include <vector>

typedef std::vector<std::vector<int>> matrix_t;
matrix_t generate(int height, int width, int min);
void print_matrix(matrix_t matrix);