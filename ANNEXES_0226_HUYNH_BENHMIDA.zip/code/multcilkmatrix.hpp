#include "matrix.hpp"

matrix_t multiplyCILK(matrix_t matrixOne, matrix_t matrixTwo);
