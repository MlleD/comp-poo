#ifndef __MATRIX_H__
#define __MATRIX_H__
#include "matrix.hpp"
#endif

matrix_t multiplySEQ(matrix_t matrixOne, matrix_t matrixTwo);