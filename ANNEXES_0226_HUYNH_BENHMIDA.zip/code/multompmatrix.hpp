#include "matrix.hpp"

matrix_t multiplyOMP(matrix_t matrixOne, matrix_t matrixTwo);
